tradutor = {
    'um': 'one',
    'dois' : 'two',
    'três' : 'three'

}

print(tradutor['três'])

tradutor['quatro'] = "four" 
print(tradutor)

del tradutor['dois']
print(tradutor)

tradutor.get("um")


chaves= tradutor.keys()
chaves= list(chaves)
print(chaves)


valores = tradutor.values()
valores = list(valores)
print(valores)

 # iterar sobre o dicionario

for chave in tradutor:
    print (chave, tradutor[chave])

# iterar pela chave e valor ao mmesmo tempo 
for chave, valor in tradutor.items():
    print(chave,valor)