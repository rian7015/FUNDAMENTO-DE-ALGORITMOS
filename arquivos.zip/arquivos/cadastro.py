contatos = open("contatos.txt", "a")

while True:
    nome =input("Digite o nome: ")
    if nome == "":
        break
    telefone = input("Digite o telefone: ")
    contatos.write("%s-%s \n" % (nome, telefone))

contatos.close() 