par = open("pares.txt", "w")
impar = open("impares.txt", "w")

for n in range(1000):
    if n % 2 == 0: #numero par
        par.write(str(n)+"\n")

    else:
        impar.write(str(n) + "\n")
        

par.close()
impar.close()             