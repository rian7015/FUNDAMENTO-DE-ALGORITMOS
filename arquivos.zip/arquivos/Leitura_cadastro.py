contatos = open("contatos.txt", "r")


# conteudo = contatos.readlines()
# print(conteudo)

for linha in contatos.readlines():
    dados = linha.split("-")
    print(dados[0])
