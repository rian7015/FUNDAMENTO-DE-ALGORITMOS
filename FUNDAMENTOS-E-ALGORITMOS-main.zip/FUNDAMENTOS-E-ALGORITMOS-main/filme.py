filmes = ["carros","matrix","killbill", "carros","toy store"]

filme = "carros"

for índice in range(len(filmes)):
    if filmes[índice]== 'carros':
        print(índice)

for f in filmes:
    if f == filme:
        print("contido na lista")
        
if filme in filmes:
    print("contido na lista")
else:
    print("não existe")



    
        
