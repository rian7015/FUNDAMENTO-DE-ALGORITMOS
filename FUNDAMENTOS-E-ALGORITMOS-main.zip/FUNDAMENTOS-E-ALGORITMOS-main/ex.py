valores = []

contador = 0
while contador < 5:
    numero = input('digite um numero')
    valores.append(numero)
    contador = contador

    print(valores)
    print(valores[0])
    print(valores[4])


print.len(valores)