Lista = []

Lista2 = [2,5,7]
print(Lista2)
print(Lista2[1])
print(Lista2[0])

Lista.append('boa noite')
print(Lista)
Lista.append(25)
print(Lista)
Lista[0]="bom dia"
print(Lista)
Lista2.insert(2,9)
print(Lista2)

Lista2.pop(1)
print(Lista2)
Lista2.remove(9)
print(Lista2)

print(Lista2[len(Lista2)-1])

print(Lista2[-1]) 



