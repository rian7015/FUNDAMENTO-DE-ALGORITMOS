T=[11,7,2,4]

menor_valor = T[0]

for n in T:
    if n < menor_valor:
        menor_valor = n 
print(menor_valor)

